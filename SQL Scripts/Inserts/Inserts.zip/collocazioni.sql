insert into Sql1259724_5.collocazioni (id_collocazione, id_istituto, scaffale)
values  (1, 1, 'F57'),
        (2, 1, 'A03'),
        (3, 1, 'C02'),
        (4, 1, 'A01'),
        (5, 1, 'B01'),
        (6, 1, 'C01'),
        (33, 1, 'A1'),
        (34, 1, 'A88'),
        (37, 1, 'B2'),
        (36, 1, 'C2'),
        (35, 1, 'B02');
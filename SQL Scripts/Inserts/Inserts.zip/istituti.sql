insert into Sql1259724_5.istituti (id_istituto, nome_istituto)
values  (1, 'ITT'),
        (2, 'LAC'),
        (3, 'LAV'),
        (4, 'EXT');